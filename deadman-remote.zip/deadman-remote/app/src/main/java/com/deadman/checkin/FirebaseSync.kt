package com.deadman.checkin

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Everything the app needs from Firebase, in one place. Plain REST calls
 * (no SDK) against https://{project}.firebaseio.com/{secret}/tablets/{id}.
 *
 * Schema per tablet (fields not written by one side are simply absent):
 *   gatekeepTriggered: Bool    - remote command, independent of local toggle
 *   repeaterTriggered: Bool    - remote command, independent of local toggle
 *   pauseUntil: Long           - epoch ms; "now < this" means paused
 *   disable: Bool              - remote "disable this installation" command
 *   disableConfirmed: Bool     - tablet's ack, cleared by you toggling off
 *   resetTimerTs: Long         - one-shot marker (nonce), newer = act on it
 *   limitMinutes: Long         - most-recent-wins against the app's own value
 *   limitMinutesTs: Long       - timestamp of whichever side set it last
 *   pendingCode: String        - a code the webpage wants to push down
 *   pendingCodeTs: Long        - timestamp of that push
 *   codeChangeTs: Long         - echoed back by the tablet: last applied change
 *   codeConfirmed: Bool        - true once the tablet has applied pendingCode
 *   lastSeen: Long             - heartbeat, written every check-in
 *   gatekeepActive: Bool       - echo of what's actually firing right now
 *   repeaterActive: Bool       - echo
 */
object FirebaseSync {

    fun pull(tabletId: String): JSONObject? {
        if (tabletId.isBlank()) return null
        return try {
            val url = URL("${Config.FIREBASE_URL}/${Config.FIREBASE_SECRET}/tablets/$tabletId.json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "GET"
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            conn.disconnect()
            if (body.isBlank() || body == "null") JSONObject() else JSONObject(body)
        } catch (e: Exception) {
            null // no connectivity / unreachable; caller treats this as "unknown"
        }
    }

    /** Partial update (PATCH semantics) without clobbering sibling fields. */
    fun push(tabletId: String, fields: Map<String, Any?>): Boolean {
        if (tabletId.isBlank()) return false
        return try {
            val url = URL("${Config.FIREBASE_URL}/${Config.FIREBASE_SECRET}/tablets/$tabletId.json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "POST"
            // HttpURLConnection has no native PATCH; Firebase honors this override header.
            conn.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            conn.setRequestProperty("Content-Type", "application/json")
            conn.doOutput = true
            val json = JSONObject()
            for ((k, v) in fields) json.put(k, v ?: JSONObject.NULL)
            conn.outputStream.use { it.write(json.toString().toByteArray()) }
            val code = conn.responseCode
            conn.disconnect()
            code in 200..299
        } catch (e: Exception) {
            false
        }
    }
}
