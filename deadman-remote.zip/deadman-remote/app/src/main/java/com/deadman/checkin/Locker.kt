package com.deadman.checkin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

object Locker {
    fun isAdminActive(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        return dpm.isAdminActive(admin)
    }

    fun lock(ctx: Context) {
        if (!isAdminActive(ctx)) return
        ctx.getSystemService(DevicePolicyManager::class.java).lockNow()
    }
}
