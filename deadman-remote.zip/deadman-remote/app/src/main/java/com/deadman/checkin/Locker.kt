package com.deadman.checkin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context

object Locker {
    fun isAdminActive(ctx: Context): Boolean {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        return dpm.isAdminActive(admin)
    }

    // Call this ONCE per trigger episode only (see Store.initialLockDone).
    // lockNow() turns the screen off like a power-button press; calling it
    // from a screen-on handler creates an infinite on/off flash loop with
    // no way back in. Never wire this to ACTION_SCREEN_ON again.
    fun lockOnce(ctx: Context) {
        val store = Store(ctx)
        if (store.initialLockDone) return
        if (!isAdminActive(ctx)) return
        ctx.getSystemService(DevicePolicyManager::class.java).lockNow()
        store.initialLockDone = true
    }
}
