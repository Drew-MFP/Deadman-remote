package com.deadman.checkin

import android.app.Activity
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Shown immediately after the recovery phrase is accepted. Mandatory: there
 * is no way back without setting a new code. Deliberately does NOT touch
 * Store.code until both fields match — so if power is lost before this
 * completes, the OLD code is still what works (Store.code was never
 * overwritten), per the explicit "don't lose the old code mid-flow" design.
 */
class RecoveryResetActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val store = Store(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(100, 100, 100, 100)
        }
        root.addView(TextView(this).apply {
            text = "Recovery accepted.\nSet a new code to continue."
            textSize = 20f
            gravity = Gravity.CENTER
        })
        val newCode = EditText(this).apply {
            hint = "New code"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        val confirmCode = EditText(this).apply {
            hint = "Re-enter new code"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        root.addView(newCode)
        root.addView(confirmCode)
        root.addView(Button(this).apply {
            text = "Set code"
            setOnClickListener {
                val a = newCode.text.toString()
                val b = confirmCode.text.toString()
                if (a.isBlank()) {
                    Toast.makeText(this@RecoveryResetActivity, "Code can't be blank", Toast.LENGTH_SHORT).show()
                } else if (a != b) {
                    Toast.makeText(this@RecoveryResetActivity, "Codes don't match", Toast.LENGTH_SHORT).show()
                    confirmCode.setText("")
                } else {
                    // Only now is the old code replaced.
                    store.code = a
                    store.codeChangeTs = System.currentTimeMillis()
                    store.recoveryModeActive = false
                    store.gatekeepActive = false
                    store.repeaterActive = false
                    store.initialLockDone = false
                    // Same remote-flag rule as a normal unlock: a short snooze,
                    // Firebase triggers are left alone (clear them from the
                    // webpage or with "Clear Remote Triggers" in Setup).
                    store.snoozeUntil = System.currentTimeMillis() + Config.SNOOZE_MINUTES * 60_000L
                    OverlayLock.hide(this@RecoveryResetActivity)
                    Toast.makeText(this@RecoveryResetActivity, "New code set", Toast.LENGTH_LONG).show()
                    finish()
                }
            }
        })
        setContentView(root)
    }

    // No way out except setting a new code.
    override fun onBackPressed() { /* no-op, intentionally */ }
}
