package com.deadman.checkin

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("deadman", Context.MODE_PRIVATE)

    var tabletId: String
        get() = p.getString("tabletId", "") ?: ""
        set(v) = p.edit().putString("tabletId", v).apply()

    var code: String
        get() = p.getString("code", "") ?: ""
        set(v) = p.edit().putString("code", v).apply()

    var limitMinutes: Long
        get() = p.getLong("limit", 20160L) // 14 days
        set(v) = p.edit().putLong("limit", v).apply()

    var lastCheckIn: Long
        get() = p.getLong("last", 0L)
        set(v) = p.edit().putLong("last", v).apply()

    var armed: Boolean
        get() = p.getBoolean("armed", false)
        set(v) = p.edit().putBoolean("armed", v).apply()

    var triggered: Boolean
        get() = p.getBoolean("triggered", false)
        set(v) = p.edit().putBoolean("triggered", v).apply()

    var snoozeUntil: Long
        get() = p.getLong("snoozeUntil", 0L)
        set(v) = p.edit().putLong("snoozeUntil", v).apply()

    // Guards against the lockNow()-on-screen-on loop: we only ever want to
    // force-lock ONCE per trigger episode, right when it starts.
    var initialLockDone: Boolean
        get() = p.getBoolean("initialLockDone", false)
        set(v) = p.edit().putBoolean("initialLockDone", v).apply()

    fun snoozed(): Boolean = System.currentTimeMillis() < snoozeUntil
}
