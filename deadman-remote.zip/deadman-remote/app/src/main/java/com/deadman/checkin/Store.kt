package com.deadman.checkin

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("deadman", Context.MODE_PRIVATE)

    // Set by you in the Setup screen, not hardcoded.
    var tabletId: String
        get() = p.getString("tabletId", "") ?: ""
        set(v) = p.edit().putString("tabletId", v).apply()

    var code: String
        get() = p.getString("code", "") ?: ""
        set(v) = p.edit().putString("code", v).apply()

    var limitMinutes: Long
        get() = p.getLong("limit", 20160L) // 14 days
        set(v) = p.edit().putLong("limit", v).apply()

    var lastCheckIn: Long
        get() = p.getLong("last", 0L)
        set(v) = p.edit().putLong("last", v).apply()

    var armed: Boolean
        get() = p.getBoolean("armed", false)
        set(v) = p.edit().putBoolean("armed", v).apply()

    var triggered: Boolean
        get() = p.getBoolean("triggered", false)
        set(v) = p.edit().putBoolean("triggered", v).apply()

    // Set the moment the correct code is entered; ignore new triggers until this time passes.
    var snoozeUntil: Long
        get() = p.getLong("snoozeUntil", 0L)
        set(v) = p.edit().putLong("snoozeUntil", v).apply()

    fun snoozed(): Boolean = System.currentTimeMillis() < snoozeUntil
}
