package com.deadman.checkin

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

/** Runs only while the tablet is in "triggered" state. Re-shows the overlay
 *  every time the screen turns on. IMPORTANT: this must never call
 *  Locker.lockOnce()/lockNow() from the screen-on handler — lockNow() turns
 *  the screen off, which re-fires ACTION_SCREEN_ON, which locks again,
 *  forever, with no way to type a code. The one-time lock happens in
 *  CheckWorker when a trigger first fires, guarded by Store.initialLockDone. */
class LockForegroundService : Service() {
    private val channelId = "deadman_guard"
    private var receiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val store = Store(context)
                if (!store.armed) { stopSelfSafely(); return }
                if (!store.triggered || store.snoozed()) return
                // Screen-on while triggered: show the overlay only. No lockNow() here.
                OverlayLock.show(context)
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(receiver, filter)

        val store = Store(this)
        if (store.triggered && !store.snoozed()) {
            OverlayLock.show(this)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val store = Store(this)
        if (!store.armed || !store.triggered) { stopSelfSafely() }
        return START_STICKY
    }

    private fun stopSelfSafely() {
        OverlayLock.hide(this)
        stopSelf()
    }

    override fun onDestroy() {
        try { receiver?.let { unregisterReceiver(it) } } catch (e: Exception) {}
        super.onDestroy()
    }

    private fun buildNotification(): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(channelId, "Background", NotificationManager.IMPORTANCE_MIN)
            mgr.createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Device Care")
            .setContentText("Optimizing storage")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    companion object {
        fun start(ctx: Context) {
            val intent = Intent(ctx, LockForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(intent)
            else ctx.startService(intent)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LockForegroundService::class.java))
        }
    }
}
