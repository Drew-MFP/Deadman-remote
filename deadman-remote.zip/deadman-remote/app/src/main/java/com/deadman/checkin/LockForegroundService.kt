package com.deadman.checkin

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

/** Runs only while gatekeepActive or repeaterActive is true.
 *  - gatekeep: shows the overlay and leaves it up; re-shown on every screen-on.
 *  - repeater: re-shows the overlay every Config.REPEATER_INTERVAL_MS, and
 *    the overlay itself lets Back dismiss it in between.
 *  IMPORTANT: never calls Locker.lockOnce()/lockNow() from here — that one-time
 *  lock happens in CheckWorker when a trigger first fires. Calling it again
 *  from a screen-on handler is what caused the v1 brick (infinite flash loop). */
class LockForegroundService : Service() {
    private val channelId = "deadman_guard"
    private var receiver: BroadcastReceiver? = null
    private val handler = Handler(Looper.getMainLooper())
    private var repeaterLoop: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(1, buildNotification())
        receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                showForCurrentMode(context)
            }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(receiver, filter)
        showForCurrentMode(this)
        armRepeaterLoopIfNeeded()
    }

    private fun showForCurrentMode(ctx: Context) {
        val store = Store(ctx)
        if (!store.armed) { stopSelfSafely(); return }
        if (store.snoozed() || store.recoveryModeActive) return
        if (store.gatekeepActive) {
            OverlayLock.show(ctx, "gatekeep")
        } else if (store.repeaterActive) {
            OverlayLock.show(ctx, "repeater")
        }
    }

    private fun armRepeaterLoopIfNeeded() {
        if (repeaterLoop != null) return
        val loop = object : Runnable {
            override fun run() {
                val store = Store(this@LockForegroundService)
                if (!store.armed) { stopSelfSafely(); return }
                if (store.repeaterActive && !store.gatekeepActive && !store.snoozed() && !store.recoveryModeActive) {
                    OverlayLock.show(this@LockForegroundService, "repeater")
                }
                if (store.gatekeepActive || store.repeaterActive) {
                    handler.postDelayed(this, Config.REPEATER_INTERVAL_MS)
                } else {
                    repeaterLoop = null
                }
            }
        }
        repeaterLoop = loop
        handler.postDelayed(loop, Config.REPEATER_INTERVAL_MS)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val store = Store(this)
        if (!store.armed || !(store.gatekeepActive || store.repeaterActive)) { stopSelfSafely() }
        else armRepeaterLoopIfNeeded()
        return START_STICKY
    }

    private fun stopSelfSafely() {
        repeaterLoop?.let { handler.removeCallbacks(it) }
        repeaterLoop = null
        OverlayLock.hide(this)
        stopSelf()
    }

    override fun onDestroy() {
        try { receiver?.let { unregisterReceiver(it) } } catch (e: Exception) {}
        repeaterLoop?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }

    private fun buildNotification(): android.app.Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val mgr = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(channelId, "Background", NotificationManager.IMPORTANCE_MIN)
            mgr.createNotificationChannel(ch)
        }
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Device Care")
            .setContentText("Optimizing storage")
            .setSmallIcon(android.R.drawable.ic_menu_save)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .build()
    }

    companion object {
        fun start(ctx: Context) {
            val intent = Intent(ctx, LockForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) ctx.startForegroundService(intent)
            else ctx.startService(intent)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, LockForegroundService::class.java))
        }
    }
}
