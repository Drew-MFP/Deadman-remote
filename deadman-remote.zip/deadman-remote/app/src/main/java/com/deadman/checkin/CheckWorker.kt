package com.deadman.checkin

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.net.HttpURLConnection
import java.net.URL

class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val store = Store(ctx)
        if (!store.armed) return Result.success()

        SecureSettingsHelper.enableAccessibilityService(ctx)

        if (store.snoozed()) {
            return Result.success()
        }

        var shouldTrigger = store.triggered

        if (!shouldTrigger) {
            if (fetchRemoteTrigger(store.tabletId)) {
                shouldTrigger = true
            } else if (System.currentTimeMillis() >= store.lastCheckIn + store.limitMinutes * 60_000L) {
                shouldTrigger = true
            }
        }

        if (shouldTrigger) {
            val wasAlreadyTriggered = store.triggered
            store.triggered = true
            if (!wasAlreadyTriggered) {
                // Fresh trigger: lock exactly once. initialLockDone guards against
                // this ever repeating on its own.
                Locker.lockOnce(ctx)
            }
            LockForegroundService.start(ctx)
        }

        return Result.success()
    }

    private fun fetchRemoteTrigger(tabletId: String): Boolean {
        if (tabletId.isBlank()) return false
        return try {
            val url = URL("${Config.FIREBASE_URL}/${Config.FIREBASE_SECRET}/tablets/$tabletId/triggered.json")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 10_000
            conn.readTimeout = 10_000
            conn.requestMethod = "GET"
            val body = conn.inputStream.bufferedReader().use { it.readText() }.trim()
            conn.disconnect()
            body == "true"
        } catch (e: Exception) {
            false
        }
    }
}
