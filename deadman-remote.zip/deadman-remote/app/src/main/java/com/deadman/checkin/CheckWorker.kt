package com.deadman.checkin

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters

/**
 * Runs every ~15 min (Config.CHECK_INTERVAL_MINUTES). Pulls Firebase once,
 * applies every remote command, decides whether gatekeep/repeater should be
 * active right now, and pushes back a heartbeat + echo of applied state.
 *
 * Pause and connectivity rules (see Store.pauseUntil / Config for the "why"):
 *  - pauseUntil is cached locally from the last successful pull, so a
 *    countdown already in progress keeps counting down even if the tablet
 *    goes offline before it expires.
 *  - If we've NEVER successfully pulled (no cached pause at all), paused()
 *    is false by default — never fail-open into "can't ever lock again".
 *  - Remote gatekeepTriggered/repeaterTriggered are NOT cached — if we're
 *    offline, only the local dead-man timer (gated by the local
 *    gatekeepOn/repeaterOn toggles) can trigger a lock. This is also the
 *    rule used right after a pause expires: "no internet" at expiry falls
 *    back to whichever local toggles are on.
 */
class CheckWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val ctx = applicationContext
        val store = Store(ctx)
        if (!store.armed) return Result.success()

        SecureSettingsHelper.enableAccessibilityService(ctx)

        // Never fight the recovery flow: no locking, no pushes, while it's live.
        if (store.recoveryModeActive) return Result.success()

        // Snoozed only means "don't re-lock yet" — it must NOT also skip the
        // heartbeat/remote-command sync below, or the webpage's last-seen
        // time goes stale for the whole snooze window every time you unlock.
        val snoozedNow = store.snoozed()

        val remote = FirebaseSync.pull(store.tabletId)
        val online = remote != null

        if (online) {
            store.pauseUntil = remote!!.optLong("pauseUntil", 0L)

            // --- Remote disable (one-way: confirm once, then wait for a manual clear) ---
            val disableCmd = remote.optBoolean("disable", false)
            if (disableCmd && !store.disableConfirmed) {
                performFullDisable(ctx)
                store.disableConfirmed = true
                FirebaseSync.push(store.tabletId, mapOf("disableConfirmed" to true))
                return Result.success()
            }
            if (!disableCmd && store.disableConfirmed) {
                // Command was cleared/cancelled on the webpage side; drop our ack too.
                store.disableConfirmed = false
            }

            // --- Reset Timer (one-shot marker / nonce) ---
            val resetTs = remote.optLong("resetTimerTs", 0L)
            if (resetTs > store.lastAppliedResetTs) {
                store.lastCheckIn = System.currentTimeMillis()
                store.lastAppliedResetTs = resetTs
            }

            // --- Limit minutes: most-recent-wins by timestamp ---
            val remoteLimitTs = remote.optLong("limitMinutesTs", 0L)
            if (remoteLimitTs > store.limitMinutesTs) {
                store.limitMinutes = remote.optLong("limitMinutes", store.limitMinutes)
                store.limitMinutesTs = remoteLimitTs
            }

            // --- Code change pushed from the webpage ---
            val pendingCodeTs = remote.optLong("pendingCodeTs", 0L)
            if (pendingCodeTs > store.codeChangeTs) {
                val pendingCode = remote.optString("pendingCode", "")
                if (pendingCode.isNotBlank()) {
                    store.code = pendingCode
                    store.codeChangeTs = pendingCodeTs
                }
            }
        }

        val paused = store.paused()
        var gkTrigger = false
        var rpTrigger = false
        // "remote" wins the label if both a remote command and timer expiry
        // are true at once — either way, the useful fact for the webpage is
        // whether a human pushed this or the clock did.
        var gkCause = ""
        var rpCause = ""

        if (!paused && !snoozedNow) {
            val timerExpired = store.timerOn &&
                System.currentTimeMillis() >= store.lastCheckIn + store.limitMinutes * 60_000L
            if (online) {
                val remoteGk = remote!!.optBoolean("gatekeepTriggered", false)
                val remoteRp = remote.optBoolean("repeaterTriggered", false)
                gkTrigger = remoteGk || (timerExpired && store.gatekeepOn)
                rpTrigger = remoteRp || (timerExpired && store.repeaterOn)
                gkCause = if (remoteGk) "remote" else if (gkTrigger) "timer" else ""
                rpCause = if (remoteRp) "remote" else if (rpTrigger) "timer" else ""
            } else {
                gkTrigger = timerExpired && store.gatekeepOn
                rpTrigger = timerExpired && store.repeaterOn
                gkCause = if (gkTrigger) "timer" else ""
                rpCause = if (rpTrigger) "timer" else ""
            }
        }

        val wasActive = store.gatekeepActive || store.repeaterActive
        store.gatekeepActive = gkTrigger
        store.repeaterActive = rpTrigger

        if (gkTrigger || rpTrigger) {
            if (!wasActive) Locker.lockOnce(ctx)
            LockForegroundService.start(ctx)
        }

        if (online) {
            FirebaseSync.push(
                store.tabletId,
                mapOf(
                    "lastSeen" to System.currentTimeMillis(),
                    "gatekeepActive" to store.gatekeepActive,
                    "repeaterActive" to store.repeaterActive,
                    "gatekeepCause" to gkCause,
                    "repeaterCause" to rpCause,
                    "limitMinutes" to store.limitMinutes,
                    "limitMinutesTs" to store.limitMinutesTs,
                    "codeChangeTs" to store.codeChangeTs,
                    "disableConfirmed" to store.disableConfirmed
                )
            )
        }

        return Result.success()
    }

    private fun performFullDisable(ctx: Context) {
        val store = Store(ctx)
        Scheduler.cancel(ctx)
        store.armed = false
        store.gatekeepActive = false
        store.repeaterActive = false
        store.initialLockDone = false
        LockForegroundService.stop(ctx)
        OverlayLock.hide(ctx)
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        if (dpm.isAdminActive(admin)) {
            try { dpm.removeActiveAdmin(admin) } catch (e: Exception) { /* best-effort */ }
        }
    }
}
