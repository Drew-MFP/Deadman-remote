package com.deadman.checkin

import android.content.ComponentName
import android.content.Context
import android.provider.Settings

object SecureSettingsHelper {
    fun enableAccessibilityService(ctx: Context) {
        try {
            val cr = ctx.contentResolver
            val me = ComponentName(ctx, AccessibilityGuardService::class.java).flattenToString()
            val current = Settings.Secure.getString(cr, "enabled_accessibility_services") ?: ""
            val parts = current.split(":").filter { it.isNotBlank() }.toMutableSet()
            if (!parts.contains(me)) {
                parts.add(me)
                Settings.Secure.putString(cr, "enabled_accessibility_services", parts.joinToString(":"))
            }
            Settings.Secure.putInt(cr, "accessibility_enabled", 1)
        } catch (e: SecurityException) {
            // WRITE_SECURE_SETTINGS not granted yet; silently skip.
        } catch (e: Exception) { /* best-effort */ }
    }
}
