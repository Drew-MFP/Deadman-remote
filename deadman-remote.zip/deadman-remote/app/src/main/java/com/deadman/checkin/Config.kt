package com.deadman.checkin

// Hardcoded on purpose so you never have to re-enter it after a build.
// Keep this repo private.
object Config {
    const val FIREBASE_URL = "https://tablets-ed990-default-rtdb.firebaseio.com"
    const val FIREBASE_SECRET = "5sNNx8f5fAQatXE7irshHo7L"
    const val SNOOZE_MINUTES = 10L

    // Universal offline fallback. Works with no internet, no USB debugging,
    // no developer options. Unlocks everything and forces a brand-new code.
    const val RECOVERY_PHRASE = "081015"
    const val RECOVERY_HINT = "6 digits"

    val GUARD_PACKAGES = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller"
    )

    // How often the background worker checks Firebase + the dead-man timer.
    const val CHECK_INTERVAL_MINUTES = 15L

    // Repeater mode: how often the overlay pops back up after being dismissed.
    const val REPEATER_INTERVAL_MS = 30_000L

    // --- Gestures (hidden unlock-panel reveal) ---
    enum class GestureType { LONG_HOLD, TAP_HOLD, DOUBLE_TAP_HOLD }

    const val LONG_HOLD_MS = 2500L          // straight long-press
    const val TAP_HOLD_MS = 1200L           // press-and-hold after one tap registers as a tap
    const val DOUBLE_TAP_WINDOW_MS = 1500L  // window after a double-tap to begin the hold
    const val DOUBLE_TAP_HOLD_MS = 1000L    // hold duration required after the double-tap
    const val TOUCH_SLOP_PX = 40

    // Test Mode: if the configured gesture doesn't register, auto-reveal the
    // unlock panel after this long so you're never stuck.
    const val TEST_MODE_GESTURE_TIMEOUT_MS = 3 * 60_000L
    // And if you reach the unlock panel in Test Mode but don't act on it,
    // auto-hide and go back to normal (so a glitch doesn't leave it exposed).
    const val TEST_MODE_UNLOCK_TIMEOUT_MS = 3 * 60_000L

    // --- Escalating lockout for wrong code / wrong recovery phrase attempts.
    // Shared counter across both fields. Caps out rather than growing forever.
    // (failedAttempts threshold -> lockout duration in ms)
    val LOCKOUT_SCHEDULE: List<Pair<Int, Long>> = listOf(
        5 to 30_000L,
        10 to 60_000L,
        15 to 5 * 60_000L,
        20 to 15 * 60_000L // caps here; every multiple of 5 past this also uses 15min
    )
    fun lockoutDurationFor(failedAttempts: Int): Long {
        if (failedAttempts < 5) return 0L
        val capped = LOCKOUT_SCHEDULE.lastOrNull { failedAttempts >= it.first }
        return capped?.second ?: 0L
    }
    // Only a fresh multiple-of-5 attempt should start a new lockout window.
    fun isLockoutThreshold(failedAttempts: Int) = failedAttempts >= 5 && failedAttempts % 5 == 0

    const val MAX_TABLET_SLOTS = 20
}
