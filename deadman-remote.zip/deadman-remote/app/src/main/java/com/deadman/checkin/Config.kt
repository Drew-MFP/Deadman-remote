package com.deadman.checkin

// Hardcoded on purpose so you never have to re-enter it after a build.
// Keep this repo private.
object Config {
    const val FIREBASE_URL = "https://tablets-ed990-default-rtdb.firebaseio.com"
    const val FIREBASE_SECRET = "5sNNx8f5fAQatXE7irshHo7L"
    const val SNOOZE_MINUTES = 10L
    val GUARD_PACKAGES = setOf(
        "com.android.settings",
        "com.android.systemui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller"
    )
}
