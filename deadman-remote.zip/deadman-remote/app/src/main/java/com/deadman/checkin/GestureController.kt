package com.deadman.checkin

import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Hidden-gesture detector for revealing the unlock panel. Built on raw
 * MotionEvents rather than android.view.GestureDetector: GestureDetector
 * only gives independent single-tap / double-tap / long-press callbacks,
 * it has no notion of "double-tap, THEN keep holding" as one combined
 * gesture, so that sequencing is tracked by hand here.
 *
 * Three gesture types (Config.GestureType):
 *  - LONG_HOLD:        press and hold.
 *  - TAP_HOLD:         one quick tap, then press and hold.
 *  - DOUBLE_TAP_HOLD:  two quick taps, then press and hold.
 *
 * Test Mode adds two independent 3-minute safety nets (see Config):
 *  - if the configured gesture never registers, auto-reveal anyway.
 *  - if you reach the unlock panel and don't act on it, auto-hide again.
 * Both are driven from the overlay, not this class, except the first one
 * which lives here since it's about gesture detection specifically.
 */
class GestureController(
    private val gestureType: String,
    private val testMode: Boolean,
    private val onReveal: () -> Unit,
    private val onTestStatus: (String) -> Unit = {}
) {
    private val handler = Handler(Looper.getMainLooper())
    private var tapCount = 0
    private var lastUpTime = 0L
    private var downX = 0f
    private var downY = 0f
    private var holdRunnable: Runnable? = null
    private var testTimeoutRunnable: Runnable? = null
    private var revealed = false

    fun attach(view: View) {
        view.setOnTouchListener { _, event -> handle(event); true }
        if (testMode) armTestTimeout()
    }

    fun detach() {
        cancelHold()
        cancelTestTimeout()
    }

    private fun handle(event: MotionEvent) {
        if (revealed) return
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> onDown(event)
            MotionEvent.ACTION_MOVE -> onMove(event)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> onUp()
        }
    }

    private fun onDown(e: MotionEvent) {
        downX = e.x
        downY = e.y
        val now = System.currentTimeMillis()
        val withinChainWindow = now - lastUpTime <= Config.DOUBLE_TAP_WINDOW_MS
        when (gestureType) {
            Config.GestureType.LONG_HOLD.name -> scheduleHold(Config.LONG_HOLD_MS)
            Config.GestureType.TAP_HOLD.name -> if (tapCount >= 1 && withinChainWindow) scheduleHold(Config.TAP_HOLD_MS)
            Config.GestureType.DOUBLE_TAP_HOLD.name -> if (tapCount >= 2 && withinChainWindow) scheduleHold(Config.DOUBLE_TAP_HOLD_MS)
        }
    }

    private fun onMove(e: MotionEvent) {
        if (abs(e.x - downX) > Config.TOUCH_SLOP_PX || abs(e.y - downY) > Config.TOUCH_SLOP_PX) {
            cancelHold()
        }
    }

    private fun onUp() {
        val hadHold = holdRunnable != null
        cancelHold()
        if (hadHold) return // was already consumed as a hold attempt that got cancelled by move; don't also count as a tap
        val now = System.currentTimeMillis()
        if (now - lastUpTime > Config.DOUBLE_TAP_WINDOW_MS) tapCount = 0
        tapCount++
        lastUpTime = now
    }

    private fun scheduleHold(ms: Long) {
        cancelHold()
        val r = Runnable { trigger() }
        holdRunnable = r
        handler.postDelayed(r, ms)
    }

    private fun cancelHold() {
        holdRunnable?.let { handler.removeCallbacks(it) }
        holdRunnable = null
    }

    private fun trigger() {
        if (revealed) return
        revealed = true
        tapCount = 0
        onTestStatus("Gesture detected")
        cancelTestTimeout()
        onReveal()
    }

    private fun armTestTimeout() {
        val r = Runnable {
            onTestStatus("No gesture detected in 3 min — auto-revealing unlock panel")
            trigger()
        }
        testTimeoutRunnable = r
        handler.postDelayed(r, Config.TEST_MODE_GESTURE_TIMEOUT_MS)
    }

    private fun cancelTestTimeout() {
        testTimeoutRunnable?.let { handler.removeCallbacks(it) }
        testTimeoutRunnable = null
    }
}
