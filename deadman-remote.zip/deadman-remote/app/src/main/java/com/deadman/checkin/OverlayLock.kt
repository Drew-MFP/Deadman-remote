package com.deadman.checkin

import android.content.Context
import android.graphics.Color
import android.os.Build
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/** Full-screen "this tablet is locked" overlay, independent of the system lock screen. */
object OverlayLock {
    private var view: View? = null

    fun canDraw(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun show(ctx: Context) {
        if (view != null) return
        if (!canDraw(ctx)) return

        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            android.graphics.PixelFormat.OPAQUE
        )

        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding(80, 80, 80, 80)
        }
        root.addView(TextView(ctx).apply {
            text = "Locked"
            setTextColor(Color.WHITE)
            textSize = 26f
            gravity = Gravity.CENTER
        })
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            setTextColor(Color.WHITE)
            hint = "Enter code"
        }
        root.addView(input)
        root.addView(Button(ctx).apply {
            text = "Unlock"
            setOnClickListener {
                val store = Store(ctx)
                if (input.text.toString() == store.code && store.code.isNotEmpty()) {
                    store.triggered = false
                    store.initialLockDone = false
                    store.snoozeUntil = System.currentTimeMillis() + Config.SNOOZE_MINUTES * 60_000L
                    hide(ctx)
                    Toast.makeText(ctx, "Unlocked for ${Config.SNOOZE_MINUTES} minutes", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Wrong code", Toast.LENGTH_SHORT).show()
                    input.setText("")
                }
            }
        })

        try {
            wm.addView(root, params)
            view = root
        } catch (e: Exception) {
            // Overlay permission missing or rejected by the ROM; nothing more we can do here.
        }
    }

    fun hide(ctx: Context) {
        val v = view ?: return
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(v)
        } catch (e: Exception) { /* already gone */ }
        view = null
    }

    fun isShowing() = view != null
}
