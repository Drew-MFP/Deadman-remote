package com.deadman.checkin

import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Full-screen lock overlay, independent of the system lock screen.
 *
 * Two modes:
 *  - "gatekeep": full block. Back button swallowed. Only the hidden
 *    gesture + code/recovery panel gets you out.
 *  - "repeater": Back is NOT swallowed — pressing it just hides this
 *    instance of the overlay; LockForegroundService brings it back every
 *    Config.REPEATER_INTERVAL_MS while repeaterActive stays true.
 */
object OverlayLock {
    private var root: FrameLayout? = null
    private var gesture: GestureController? = null
    private var currentMode: String = "gatekeep"
    private val handler = Handler(Looper.getMainLooper())
    private var testUnlockTimeout: Runnable? = null

    fun canDraw(ctx: Context) = Settings.canDrawOverlays(ctx)

    fun isShowing() = root != null

    fun show(ctx: Context, mode: String = "gatekeep") {
        val store = Store(ctx)
        if (store.recoveryModeActive) return // mid recovery flow; never re-cover it
        if (root != null) { currentMode = mode; return }
        if (!canDraw(ctx)) return

        currentMode = mode
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            type,
            WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            android.graphics.PixelFormat.OPAQUE
        )

        val frame = FrameLayout(ctx).apply {
            isFocusableInTouchMode = true
            setOnKeyListener { _, keyCode, _ ->
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    if (currentMode == "repeater") {
                        hide(ctx)
                        true
                    } else {
                        true // gatekeep: swallow, do nothing
                    }
                } else false
            }
        }

        // --- Background layer: custom HTML if set, otherwise a plain locked screen.
        val html = store.htmlContent
        if (html.isNotBlank()) {
            val web = WebView(ctx).apply {
                setBackgroundColor(Color.BLACK)
                loadDataWithBaseURL(null, Config.wrapOverlayHtml(html), "text/html", "utf-8", null)
            }
            frame.addView(web, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        } else {
            val plain = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setBackgroundColor(Color.BLACK)
                addView(TextView(ctx).apply {
                    text = "This device is protected"
                    setTextColor(Color.WHITE)
                    textSize = 22f
                    gravity = Gravity.CENTER
                })
            }
            frame.addView(plain, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
        }

        // --- Unlock panel: hidden until the gesture reveals it.
        val unlockPanel = buildUnlockPanel(ctx)
        unlockPanel.visibility = View.GONE
        frame.addView(unlockPanel, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        // --- Transparent gesture-capture layer, on top, swallows ALL touches
        // so the WebView underneath never intercepts them.
        val touchCatcher = View(ctx)
        frame.addView(touchCatcher, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))

        val gc = GestureController(
            gestureType = store.gestureType,
            testMode = store.testModeOn,
            onReveal = {
                handler.post {
                    unlockPanel.visibility = View.VISIBLE
                    touchCatcher.visibility = View.GONE
                    if (store.testModeOn) armTestUnlockTimeout(ctx)
                }
            },
            onTestStatus = { msg -> handler.post { Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show() } }
        )
        gc.attach(touchCatcher)
        gesture = gc

        try {
            wm.addView(frame, params)
            root = frame
            frame.requestFocus()
        } catch (e: Exception) {
            // Overlay permission missing or rejected by the ROM; nothing more we can do here.
        }
    }

    private fun buildUnlockPanel(ctx: Context): LinearLayout {
        val store = Store(ctx)
        val panel = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.parseColor("#DD000000"))
            setPadding(80, 80, 80, 80)
        }
        panel.addView(TextView(ctx).apply {
            text = "Enter code"
            setTextColor(Color.WHITE)
            textSize = 20f
            gravity = Gravity.CENTER
        })
        val input = EditText(ctx).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
            setTextColor(Color.WHITE)
            hint = "Code"
        }
        panel.addView(input)
        panel.addView(TextView(ctx).apply {
            text = "Forgot it? Recovery phrase hint: ${Config.RECOVERY_HINT}"
            setTextColor(Color.GRAY)
            textSize = 12f
            gravity = Gravity.CENTER
        })
        panel.addView(Button(ctx).apply {
            text = "Unlock"
            setOnClickListener { attempt(ctx, input.text.toString(), input) }
        })
        return panel
    }

    private fun attempt(ctx: Context, entered: String, input: EditText) {
        val store = Store(ctx)
        if (store.lockedOut()) {
            val secs = (store.lockoutUntil - System.currentTimeMillis()) / 1000
            Toast.makeText(ctx, "Too many wrong attempts. Try again in ${secs}s", Toast.LENGTH_LONG).show()
            return
        }
        when {
            entered.isNotEmpty() && entered == Config.RECOVERY_PHRASE -> {
                store.failedAttempts = 0
                store.recoveryModeActive = true
                hide(ctx)
                val intent = Intent(ctx, RecoveryResetActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                ctx.startActivity(intent)
            }
            entered.isNotEmpty() && store.code.isNotEmpty() && entered == store.code -> {
                store.failedAttempts = 0
                store.gatekeepActive = false
                store.repeaterActive = false
                store.initialLockDone = false
                store.snoozeUntil = System.currentTimeMillis() + Config.SNOOZE_MINUTES * 60_000L
                cancelTestUnlockTimeout()
                hide(ctx)
                Toast.makeText(ctx, "Unlocked for ${Config.SNOOZE_MINUTES} minutes", Toast.LENGTH_LONG).show()
            }
            else -> {
                store.failedAttempts += 1
                if (Config.isLockoutThreshold(store.failedAttempts)) {
                    val dur = Config.lockoutDurationFor(store.failedAttempts)
                    store.lockoutUntil = System.currentTimeMillis() + dur
                    Toast.makeText(ctx, "Too many wrong attempts. Locked out for ${dur / 1000}s", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(ctx, "Wrong code", Toast.LENGTH_SHORT).show()
                }
                input.setText("")
            }
        }
    }

    private fun armTestUnlockTimeout(ctx: Context) {
        cancelTestUnlockTimeout()
        val r = Runnable {
            val store = Store(ctx)
            // Nothing happened on the unlock panel for 3 minutes in Test Mode:
            // treat this as a glitch, not a thief standing there. Stand down
            // rather than risk a repeat of the v1 lock-out bug.
            store.testModeOn = false
            store.gatekeepActive = false
            store.repeaterActive = false
            store.initialLockDone = false
            store.snoozeUntil = System.currentTimeMillis() + Config.SNOOZE_MINUTES * 60_000L
            hide(ctx)
            Toast.makeText(ctx, "Test Mode: no action for 3 min — auto-unlocked and Test Mode turned off", Toast.LENGTH_LONG).show()
        }
        testUnlockTimeout = r
        handler.postDelayed(r, Config.TEST_MODE_UNLOCK_TIMEOUT_MS)
    }

    private fun cancelTestUnlockTimeout() {
        testUnlockTimeout?.let { handler.removeCallbacks(it) }
        testUnlockTimeout = null
    }

    fun hide(ctx: Context) {
        cancelTestUnlockTimeout()
        gesture?.detach()
        gesture = null
        val v = root ?: return
        try {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            wm.removeView(v)
        } catch (e: Exception) { /* already gone */ }
        root = null
    }
}
