package com.deadman.checkin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = Store(context)
        SecureSettingsHelper.enableAccessibilityService(context)
        if (!store.armed) return
        Scheduler.schedule(context)
        if (store.triggered && !store.snoozed()) {
            LockForegroundService.start(context)
        }
        Scheduler.runNow(context)
    }
}
