package com.deadman.checkin

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val store = Store(context)
        SecureSettingsHelper.enableAccessibilityService(context)
        if (!store.armed) return
        Scheduler.schedule(context)
        // Note: do NOT force a fresh lockOnce() here. If already triggered,
        // initialLockDone is already true from before reboot, so this just
        // restarts the overlay-showing service, not another lockNow().
        if (store.triggered && !store.snoozed()) {
            LockForegroundService.start(context)
        }
        Scheduler.runNow(context)
    }
}
