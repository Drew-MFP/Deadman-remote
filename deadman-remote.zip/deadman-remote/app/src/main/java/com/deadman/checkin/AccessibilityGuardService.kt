package com.deadman.checkin

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AccessibilityGuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val reassert = object : Runnable {
        override fun run() {
            SecureSettingsHelper.enableAccessibilityService(applicationContext)
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(reassert)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val store = Store(this)
        if (!store.triggered || store.snoozed()) return
        val pkg = event?.packageName?.toString() ?: return
        // Catch-all: while triggered, ANY foreground app that isn't us gets the
        // overlay re-shown — not just Settings/SystemUI. This is what covers
        // the launcher/recents-then-Back gap: swiping to the home screen or
        // recents switches the foreground package too, so it trips this same
        // check instead of needing its own special case.
        if (pkg != packageName) {
            if (pkg in Config.GUARD_PACKAGES) performGlobalAction(GLOBAL_ACTION_HOME)
            OverlayLock.show(this)
            // Still no lockNow() here — the overlay is enough, and calling it
            // from an event handler risks the same kind of loop as before.
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(reassert)
        super.onDestroy()
    }
}
