package com.deadman.checkin

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AccessibilityGuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val reassert = object : Runnable {
        override fun run() {
            SecureSettingsHelper.enableAccessibilityService(applicationContext)
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(reassert)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val store = Store(this)
        if (store.recoveryModeActive) return
        if (store.snoozed()) return
        val pkg = event?.packageName?.toString() ?: return
        if (pkg == packageName) return

        if (store.gatekeepActive) {
            // Full block: any foreign foreground app gets the overlay
            // re-shown, and the known Settings/SystemUI/launcher variants
            // also get bounced home first.
            if (pkg in Config.GUARD_PACKAGES) performGlobalAction(GLOBAL_ACTION_HOME)
            OverlayLock.show(this, "gatekeep")
        } else if (store.repeaterActive) {
            // "Closes any apps that open" — send it home immediately. The
            // overlay itself re-appears on its own 30s cycle (see
            // LockForegroundService), not from this event.
            performGlobalAction(GLOBAL_ACTION_HOME)
        }
        // Never calls lockNow()/Locker.lockOnce() from here — that's the
        // bug that bricked a tablet before. The overlay/home-kick is enough.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(reassert)
        super.onDestroy()
    }
}
