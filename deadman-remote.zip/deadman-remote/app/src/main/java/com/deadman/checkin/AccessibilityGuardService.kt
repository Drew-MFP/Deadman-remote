package com.deadman.checkin

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

class AccessibilityGuardService : AccessibilityService() {
    private val handler = Handler(Looper.getMainLooper())
    private val reassert = object : Runnable {
        override fun run() {
            SecureSettingsHelper.enableAccessibilityService(applicationContext)
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        handler.post(reassert)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val store = Store(this)
        if (!store.triggered || store.snoozed()) return
        val pkg = event?.packageName?.toString() ?: return
        if (pkg in Config.GUARD_PACKAGES) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            OverlayLock.show(this)
            // No lockNow() here either — the overlay plus sending them home is enough,
            // and keeps this out of the same screen-on-triggers-lock trap.
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(reassert)
        super.onDestroy()
    }
}
