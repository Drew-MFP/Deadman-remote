package com.deadman.checkin

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.widget.*

class MainActivity : Activity() {
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var store: Store
    private lateinit var status: TextView
    private lateinit var contentView: View
    private lateinit var gateView: View
    private var unlocked = false

    private fun field(hint: String, secret: Boolean = true) = EditText(this).apply {
        this.hint = hint
        inputType = if (secret) InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        else InputType.TYPE_CLASS_TEXT
    }

    private fun btn(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(DevicePolicyManager::class.java)
        admin = ComponentName(this, AdminReceiver::class.java)
        store = Store(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        contentView = ScrollView(this).apply { addView(root) }

        val gate = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 200, 48, 48) }
        gate.addView(TextView(this).apply { text = "Locked"; textSize = 24f })
        val gateCode = field("Enter code")
        gate.addView(gateCode)
        gate.addView(btn("Unlock") {
            if (gateCode.text.toString() == store.code && store.code.isNotEmpty()) {
                unlocked = true
                gateCode.setText("")
                setContentView(contentView)
                refresh()
            } else toast("Wrong code")
        })
        gateView = gate

        status = TextView(this).apply { textSize = 15f }
        root.addView(status)

        // --- Permissions ---
        root.addView(TextView(this).apply { text = "\nPermissions"; textSize = 20f })
        root.addView(btn("1. Enable device admin") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to lock the screen remotely.")
            })
        })
        root.addView(btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("3. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("4. Ignore battery optimization") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        // --- Setup ---
        root.addView(TextView(this).apply { text = "\nSetup"; textSize = 20f })
        val tabletId = field("Tablet ID (must match the switch panel)", secret = false)
        tabletId.setText(store.tabletId)
        val minutes = field("Time limit in minutes (20160 = 14 days)", secret = false)
        minutes.setText(store.limitMinutes.toString())
        val code = field("Code (used everywhere below)")
        root.addView(tabletId); root.addView(minutes); root.addView(code)
        root.addView(btn("Save & start") {
            if (!Locker.isAdminActive(this)) { toast("Enable device admin first"); return@btn }
            if (code.text.toString().isBlank()) { toast("Set a code"); return@btn }
            if (tabletId.text.toString().isBlank()) { toast("Set a tablet ID"); return@btn }
            store.tabletId = tabletId.text.toString().trim()
            store.code = code.text.toString()
            store.limitMinutes = minutes.text.toString().toLongOrNull() ?: 20160L
            store.lastCheckIn = System.currentTimeMillis()
            store.triggered = false
            store.armed = true
            SecureSettingsHelper.enableAccessibilityService(this)
            Scheduler.schedule(this)
            code.setText("")
            refresh(); toast("Saved and armed")
        })

        // --- Test ---
        root.addView(btn("Test lock now") {
            if (!Locker.isAdminActive(this)) { toast("Enable device admin first"); return@btn }
            store.triggered = true
            LockForegroundService.start(this)
            toast("Locking…")
        })

        // --- Check in ---
        root.addView(TextView(this).apply { text = "\nCheck in"; textSize = 20f })
        val checkinCode = field("Enter code")
        root.addView(checkinCode)
        root.addView(btn("Check in (resets the timer)") {
            if (checkinCode.text.toString() == store.code && store.code.isNotEmpty()) {
                store.lastCheckIn = System.currentTimeMillis()
                store.triggered = false
                checkinCode.setText(""); refresh(); toast("Timer reset")
            } else toast("Wrong code")
        })

        // --- Removal ---
        root.addView(TextView(this).apply { text = "\nRemove"; textSize = 20f })
        val rm = field("Code")
        root.addView(rm)
        root.addView(btn("Remove protection (then uninstall)") {
            if (rm.text.toString() == store.code && store.code.isNotEmpty()) {
                Scheduler.cancel(this)
                store.armed = false
                store.triggered = false
                LockForegroundService.stop(this)
                OverlayLock.hide(this)
                if (Locker.isAdminActive(this)) dpm.removeActiveAdmin(admin)
                refresh(); toast("Removed. Disable the accessibility service, then uninstall.")
            } else toast("Wrong code")
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (store.armed && store.code.isNotEmpty() && !unlocked) setContentView(gateView) else setContentView(contentView)
    }

    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    private fun refresh() {
        val admin = Locker.isAdminActive(this)
        val overlay = OverlayLock.canDraw(this)
        val left = if (store.armed) {
            val ms = store.lastCheckIn + store.limitMinutes * 60_000L - System.currentTimeMillis()
            if (ms <= 0) "due now" else "${ms / 3_600_000L}h ${(ms / 60_000L) % 60}m left"
        } else "not armed"
        val snooze = if (store.snoozed()) {
            val ms = store.snoozeUntil - System.currentTimeMillis()
            "${ms / 60_000L}m ${(ms / 1_000L) % 60}s"
        } else "no"
        status.text = "Tablet ID: ${store.tabletId}\n" +
            "Device admin: $admin\nOverlay permission: $overlay\n" +
            "Timer: $left\nTriggered: ${store.triggered}\nSnoozed: $snooze"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
