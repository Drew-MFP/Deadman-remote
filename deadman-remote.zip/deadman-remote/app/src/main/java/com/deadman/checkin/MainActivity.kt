package com.deadman.checkin

import android.app.Activity
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.view.WindowManager
import android.webkit.WebView
import android.widget.*

class MainActivity : Activity() {
    private lateinit var dpm: DevicePolicyManager
    private lateinit var admin: ComponentName
    private lateinit var store: Store
    private lateinit var status: TextView
    private lateinit var contentView: View
    private lateinit var gateView: View
    private var unlocked = false

    private fun field(hint: String, secret: Boolean = true) = EditText(this).apply {
        this.hint = hint
        inputType = if (secret) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        else InputType.TYPE_CLASS_TEXT
    }

    private fun btn(text: String, onClick: () -> Unit) =
        Button(this).apply { this.text = text; setOnClickListener { onClick() } }

    private fun header(text: String) = TextView(this).apply { this.text = "\n$text"; textSize = 20f }

    private fun bg(block: () -> Unit) = Thread(block).start()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dpm = getSystemService(DevicePolicyManager::class.java)
        admin = ComponentName(this, AdminReceiver::class.java)
        store = Store(this)

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 48, 48, 48) }
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        contentView = ScrollView(this).apply { addView(root) }

        val gate = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 200, 48, 48) }
        gate.addView(TextView(this).apply { text = "Device Care"; textSize = 24f })
        val gateCode = field("Enter code")
        gate.addView(gateCode)
        gate.addView(TextView(this).apply {
            text = "Forgot it? Recovery hint: ${Config.RECOVERY_HINT}"
            textSize = 12f
        })
        gate.addView(btn("Unlock") {
            if (gateCode.text.toString() == store.code && store.code.isNotEmpty()) {
                unlocked = true
                gateCode.setText("")
                setContentView(contentView)
                refresh()
            } else if (gateCode.text.toString() == Config.RECOVERY_PHRASE) {
                store.recoveryModeActive = true
                startActivity(Intent(this, RecoveryResetActivity::class.java))
                finish()
            } else toast("Wrong code")
        })
        gateView = gate

        status = TextView(this).apply { textSize = 15f }
        root.addView(status)

        // ---------------- Permissions ----------------
        root.addView(header("Permissions"))
        root.addView(btn("1. Enable device admin") {
            startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
                putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin)
                putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Needed to lock the screen remotely.")
            })
        })
        root.addView(btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(btn("3. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(btn("4. Ignore battery optimization") {
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:$packageName")
                })
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        })

        // ---------------- Setup ----------------
        root.addView(header("Setup"))
        val tabletSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                (1..Config.MAX_TABLET_SLOTS).map { "tablet$it" })
        }
        val existingIndex = (1..Config.MAX_TABLET_SLOTS).map { "tablet$it" }.indexOf(store.tabletId)
        if (existingIndex >= 0) tabletSpinner.setSelection(existingIndex)
        val dupWarning = TextView(this).apply { textSize = 12f; setTextColor(android.graphics.Color.RED) }
        tabletSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                val candidate = "tablet${pos + 1}"
                dupWarning.text = ""
                if (candidate != store.tabletId) {
                    bg {
                        val remote = FirebaseSync.pull(candidate)
                        val lastSeen = remote?.optLong("lastSeen", 0L) ?: 0L
                        val recentMs = System.currentTimeMillis() - lastSeen
                        runOnUiThread {
                            if (lastSeen > 0 && recentMs < 30L * 24 * 3_600_000L) {
                                dupWarning.text = "$candidate last checked in ${recentMs / 3_600_000L}h ago — " +
                                    "may already be in use by another tablet. Only reuse a slot you know is free."
                            }
                        }
                    }
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        })
        root.addView(tabletSpinner)
        root.addView(dupWarning)

        val minutes = field("Time limit in minutes (20160 = 14 days)", secret = false)
        minutes.setText(store.limitMinutes.toString())
        root.addView(minutes)

        val code = field("Code")
        val codeConfirm = field("Re-enter code to confirm")
        root.addView(code); root.addView(codeConfirm)

        root.addView(btn("Save & start") {
            if (!Locker.isAdminActive(this)) { toast("Enable device admin first"); return@btn }
            if (code.text.toString().isBlank()) { toast("Set a code"); return@btn }
            if (code.text.toString() != codeConfirm.text.toString()) { toast("Codes don't match"); return@btn }
            val tabletId = "tablet${tabletSpinner.selectedItemPosition + 1}"
            store.tabletId = tabletId
            store.code = code.text.toString()
            store.codeChangeTs = System.currentTimeMillis()
            store.limitMinutes = minutes.text.toString().toLongOrNull() ?: 20160L
            store.limitMinutesTs = System.currentTimeMillis()
            store.lastCheckIn = System.currentTimeMillis()
            store.gatekeepActive = false
            store.repeaterActive = false
            store.initialLockDone = false
            store.armed = true
            SecureSettingsHelper.enableAccessibilityService(this)
            Scheduler.schedule(this)
            code.setText(""); codeConfirm.setText("")
            bg {
                FirebaseSync.push(tabletId, mapOf(
                    "codeChangeTs" to store.codeChangeTs, "codeConfirmed" to true,
                    "limitMinutes" to store.limitMinutes, "limitMinutesTs" to store.limitMinutesTs,
                    "lastSeen" to System.currentTimeMillis()
                ))
            }
            runOnUiThread { refresh(); toast("Saved and armed") }
        })

        // ---------------- Modes ----------------
        root.addView(header("Modes"))
        val gatekeepSwitch = Switch(this).apply { text = "Gatekeep (full lock, blocks everything)"; isChecked = store.gatekeepOn }
        val repeaterSwitch = Switch(this).apply { text = "Repeater (pops up every 30s, Back allowed)"; isChecked = store.repeaterOn }
        val timerSwitch = Switch(this).apply { text = "Dead-man timer (auto-trigger if no check-in)"; isChecked = store.timerOn }
        root.addView(gatekeepSwitch); root.addView(repeaterSwitch); root.addView(timerSwitch)

        timerSwitch.setOnCheckedChangeListener { _, checked ->
            store.timerOn = checked
            if (checked && !store.gatekeepOn && !store.repeaterOn) {
                // Safeguard: turning the timer on with nothing to fire is pointless.
                store.gatekeepOn = true
                store.repeaterOn = true
                gatekeepSwitch.isChecked = true
                repeaterSwitch.isChecked = true
                toast("Turned on Gatekeep + Repeater so the timer has something to trigger")
            }
        }
        gatekeepSwitch.setOnCheckedChangeListener { _, checked ->
            store.gatekeepOn = checked
            if (store.timerOn && !store.gatekeepOn && !store.repeaterOn) {
                toast("Warning: timer is on but both modes are off — it won't be able to do anything")
            }
        }
        repeaterSwitch.setOnCheckedChangeListener { _, checked ->
            store.repeaterOn = checked
            if (store.timerOn && !store.gatekeepOn && !store.repeaterOn) {
                toast("Warning: timer is on but both modes are off — it won't be able to do anything")
            }
        }

        // ---------------- Gestures ----------------
        root.addView(header("Hidden unlock gesture"))
        val gestureSpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("Long hold", "Tap, then hold", "Double-tap, then hold"))
            setSelection(when (store.gestureType) {
                Config.GestureType.LONG_HOLD.name -> 0
                Config.GestureType.DOUBLE_TAP_HOLD.name -> 2
                else -> 1
            })
        }
        gestureSpinner.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                store.gestureType = when (pos) {
                    0 -> Config.GestureType.LONG_HOLD.name
                    2 -> Config.GestureType.DOUBLE_TAP_HOLD.name
                    else -> Config.GestureType.TAP_HOLD.name
                }
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        })
        root.addView(gestureSpinner)
        val testModeSwitch = Switch(this).apply {
            text = "Test Mode (auto-reveal/auto-unlock safety timers — turn off once gestures work)"
            isChecked = store.testModeOn
        }
        testModeSwitch.setOnCheckedChangeListener { _, checked -> store.testModeOn = checked }
        root.addView(testModeSwitch)

        // ---------------- HTML overlay content ----------------
        root.addView(header("Lock screen content (optional HTML)"))
        val htmlField = EditText(this).apply {
            hint = "<h1>Lost phone</h1><p>If found call 555-1234</p>"
            setText(store.htmlContent)
            minLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
        root.addView(htmlField)
        root.addView(btn("Save content") {
            store.htmlContent = htmlField.text.toString()
            toast("Saved")
        })
        root.addView(btn("Preview") {
            val web = WebView(this).apply {
                val html = htmlField.text.toString()
                loadDataWithBaseURL(null, if (html.isBlank()) "<body style='background:black;color:white'><h1>This device is protected</h1></body>" else html, "text/html", "utf-8", null)
            }
            AlertDialog.Builder(this).setView(web).setPositiveButton("Close", null).show()
        })

        // ---------------- Check in ----------------
        root.addView(header("Check in"))
        val checkinCode = field("Enter code")
        root.addView(checkinCode)
        root.addView(btn("Check in (resets the timer)") {
            if (checkinCode.text.toString() == store.code && store.code.isNotEmpty()) {
                store.lastCheckIn = System.currentTimeMillis()
                store.gatekeepActive = false
                store.repeaterActive = false
                store.initialLockDone = false
                checkinCode.setText(""); refresh(); toast("Timer reset")
            } else toast("Wrong code")
        })
        root.addView(btn("Reset timer (local + push)") {
            store.lastCheckIn = System.currentTimeMillis()
            val ts = System.currentTimeMillis()
            bg { FirebaseSync.push(store.tabletId, mapOf("resetTimerTs" to ts)); store.lastAppliedResetTs = ts }
            toast("Timer reset")
        })
        root.addView(btn("Clear remote triggers (requires code)") {
            if (checkinCode.text.toString() == store.code && store.code.isNotEmpty()) {
                bg { FirebaseSync.push(store.tabletId, mapOf("gatekeepTriggered" to false, "repeaterTriggered" to false)) }
                store.gatekeepActive = false
                store.repeaterActive = false
                checkinCode.setText(""); refresh()
                toast("Will clear once online")
            } else toast("Wrong code")
        })
        root.addView(btn("End snooze now") {
            if (checkinCode.text.toString() == store.code && store.code.isNotEmpty()) {
                store.snoozeUntil = 0L
                checkinCode.setText(""); refresh(); toast("Snooze ended")
            } else toast("Wrong code")
        })

        root.addView(btn("Test lock now") {
            if (!Locker.isAdminActive(this)) { toast("Enable device admin first"); return@btn }
            store.gatekeepActive = true
            store.initialLockDone = false
            Locker.lockOnce(this)
            LockForegroundService.start(this)
            toast("Locking…")
        })

        // ---------------- Remove ----------------
        root.addView(header("Remove"))
        val rm = field("Code")
        root.addView(rm)
        root.addView(btn("Remove protection (then uninstall)") {
            if (rm.text.toString() == store.code && store.code.isNotEmpty()) {
                Scheduler.cancel(this)
                store.armed = false
                store.gatekeepActive = false
                store.repeaterActive = false
                store.initialLockDone = false
                LockForegroundService.stop(this)
                OverlayLock.hide(this)
                if (Locker.isAdminActive(this)) dpm.removeActiveAdmin(admin)
                refresh(); toast("Removed. Disable the accessibility service, then uninstall.")
            } else toast("Wrong code")
        })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        if (store.armed && store.code.isNotEmpty() && !unlocked && !store.recoveryModeActive) setContentView(gateView)
        else setContentView(contentView)
    }

    override fun onStop() {
        super.onStop()
        unlocked = false
    }

    private fun refresh() {
        val adminActive = Locker.isAdminActive(this)
        val overlay = OverlayLock.canDraw(this)
        val left = if (store.armed && store.timerOn) {
            val ms = store.lastCheckIn + store.limitMinutes * 60_000L - System.currentTimeMillis()
            if (ms <= 0) "due now" else "${ms / 3_600_000L}h ${(ms / 60_000L) % 60}m left"
        } else "timer off"
        val snooze = if (store.snoozed()) {
            val ms = store.snoozeUntil - System.currentTimeMillis()
            "${ms / 60_000L}m ${(ms / 1_000L) % 60}s"
        } else "no"
        val pause = if (store.paused()) {
            val ms = store.pauseUntil - System.currentTimeMillis()
            "${ms / 60_000L}m left"
        } else "no"
        status.text = "Tablet ID: ${store.tabletId}\n" +
            "Device admin: $adminActive\nOverlay permission: $overlay\n" +
            "Gatekeep: on=${store.gatekeepOn} active=${store.gatekeepActive}\n" +
            "Repeater: on=${store.repeaterOn} active=${store.repeaterActive}\n" +
            "Timer: $left\nPaused: $pause\nSnoozed: $snooze\n" +
            "Locked out: ${store.lockedOut()}"
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
