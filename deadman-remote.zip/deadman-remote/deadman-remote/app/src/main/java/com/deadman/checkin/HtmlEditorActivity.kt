package com.deadman.checkin

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Dedicated full-screen editor for the lock-screen HTML content, since typing
 * anything beyond a line or two in a cramped field on the main Setup screen
 * is unworkable. Preview shows exactly what OverlayLock will render (same
 * Config.wrapOverlayHtml wrapper). Save writes Store.htmlContent and returns
 * to MainActivity; nothing is saved until you tap Save.
 */
class HtmlEditorActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }
        root.addView(TextView(this).apply {
            text = "Lock screen HTML"
            textSize = 20f
        })
        root.addView(TextView(this).apply {
            text = "Plain text works fine too — it's centered and sized automatically. " +
                "Add your own HTML tags if you want more control."
            textSize = 12f
            setPadding(0, 0, 0, 16)
        })

        val field = EditText(this).apply {
            setText(store.htmlContent)
            hint = "<h1>Lost tablet</h1><p>If found, call 555-1234</p>"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            gravity = android.view.Gravity.TOP
            setLines(16)
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(field)

        val buttonRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        buttonRow.addView(Button(this).apply {
            text = "Preview"
            setOnClickListener {
                val web = WebView(this@HtmlEditorActivity).apply {
                    loadDataWithBaseURL(null, Config.wrapOverlayHtml(field.text.toString()), "text/html", "utf-8", null)
                }
                AlertDialog.Builder(this@HtmlEditorActivity).setView(web).setPositiveButton("Close", null).show()
            }
        })
        buttonRow.addView(Button(this).apply {
            text = "Save"
            setOnClickListener {
                store.htmlContent = field.text.toString()
                Toast.makeText(this@HtmlEditorActivity, "Saved", Toast.LENGTH_SHORT).show()
                finish()
            }
        })
        root.addView(buttonRow)

        setContentView(root)
    }
}
