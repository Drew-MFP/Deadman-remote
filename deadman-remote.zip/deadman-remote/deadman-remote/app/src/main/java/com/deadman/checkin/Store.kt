package com.deadman.checkin

import android.content.Context

class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("deadman", Context.MODE_PRIVATE)

    // ---------- Identity / setup ----------
    var tabletId: String
        get() = p.getString("tabletId", "") ?: ""
        set(v) = p.edit().putString("tabletId", v).apply()

    var code: String
        get() = p.getString("code", "") ?: ""
        set(v) = p.edit().putString("code", v).apply()

    // Bumped every time `code` changes (locally or via remote change-code
    // sync), so both sides can tell whose code value is newer.
    var codeChangeTs: Long
        get() = p.getLong("codeChangeTs", 0L)
        set(v) = p.edit().putLong("codeChangeTs", v).apply()

    var armed: Boolean
        get() = p.getBoolean("armed", false)
        set(v) = p.edit().putBoolean("armed", v).apply()

    // ---------- Dead-man timer ----------
    var limitMinutes: Long
        get() = p.getLong("limit", 20160L) // 14 days
        set(v) = p.edit().putLong("limit", v).apply()

    // Timestamp of whichever side (app or webpage) last changed limitMinutes.
    // "Most recent wins" sync applies ONLY to this field.
    var limitMinutesTs: Long
        get() = p.getLong("limitTs", 0L)
        set(v) = p.edit().putLong("limitTs", v).apply()

    var lastCheckIn: Long
        get() = p.getLong("last", 0L)
        set(v) = p.edit().putLong("last", v).apply()

    // Nonce for the remote "Reset Timer" button: a timestamp marker. We only
    // act on it once (when it's newer than the last one we applied).
    var lastAppliedResetTs: Long
        get() = p.getLong("lastAppliedResetTs", 0L)
        set(v) = p.edit().putLong("lastAppliedResetTs", v).apply()

    // ---------- Modes (local toggles) ----------
    var gatekeepOn: Boolean
        get() = p.getBoolean("gatekeepOn", true)
        set(v) = p.edit().putBoolean("gatekeepOn", v).apply()

    var repeaterOn: Boolean
        get() = p.getBoolean("repeaterOn", false)
        set(v) = p.edit().putBoolean("repeaterOn", v).apply()

    // Whether the dead-man timer is allowed to fire at all. Remotely
    // toggleable (webpage/control app) — timerOnTs is when this value was
    // last applied, from whichever side (local or remote) changed it most
    // recently, and is echoed every check-in for the webpage/control app's
    // Pending/Confirmed badge.
    var timerOn: Boolean
        get() = p.getBoolean("timerOn", true)
        set(v) = p.edit().putBoolean("timerOn", v).apply()
    var timerOnTs: Long
        get() = p.getLong("timerOnTs", 0L)
        set(v) = p.edit().putLong("timerOnTs", v).apply()

    // ---------- Effective trigger state (what's actually firing right now) ----------
    // Each is the OR of: local timer expiry (if timerOn + that mode is on)
    // and the matching remote *Triggered flag — unless paused. These are
    // computed by CheckWorker and consumed by the lock screen/services.
    var gatekeepActive: Boolean
        get() = p.getBoolean("gatekeepActive", false)
        set(v) = p.edit().putBoolean("gatekeepActive", v).apply()

    var repeaterActive: Boolean
        get() = p.getBoolean("repeaterActive", false)
        set(v) = p.edit().putBoolean("repeaterActive", v).apply()

    // Guards against the lockNow()-on-screen-on loop: we only ever want to
    // force-lock ONCE per trigger episode, right when it starts.
    var initialLockDone: Boolean
        get() = p.getBoolean("initialLockDone", false)
        set(v) = p.edit().putBoolean("initialLockDone", v).apply()

    var snoozeUntil: Long
        get() = p.getLong("snoozeUntil", 0L)
        set(v) = p.edit().putLong("snoozeUntil", v).apply()

    fun snoozed(): Boolean = System.currentTimeMillis() < snoozeUntil

    // ---------- Pause (universal override, countdown-based) ----------
    // While now() < pauseUntil, NOTHING locks — not a remote trigger, not the
    // timer. If connectivity is lost while paused, the tablet can't see that
    // pause has a value at all once it expires locally-cached-read fails, so
    // it falls back to triggering normally (fail-safe, never fail-open).
    var pauseUntil: Long
        get() = p.getLong("pauseUntil", 0L)
        set(v) = p.edit().putLong("pauseUntil", v).apply()

    fun paused(): Boolean = System.currentTimeMillis() < pauseUntil

    // ---------- Disable (remote "wipe this slot") ----------
    var disableConfirmed: Boolean
        get() = p.getBoolean("disableConfirmed", false)
        set(v) = p.edit().putBoolean("disableConfirmed", v).apply()

    // ---------- Gestures ----------
    var gestureType: String
        get() = p.getString("gestureType", Config.GestureType.TAP_HOLD.name) ?: Config.GestureType.TAP_HOLD.name
        set(v) = p.edit().putString("gestureType", v).apply()

    var testModeOn: Boolean
        get() = p.getBoolean("testModeOn", false)
        set(v) = p.edit().putBoolean("testModeOn", v).apply()
    // Same remote-toggle + echo pattern as timerOnTs, see above.
    var testModeOnTs: Long
        get() = p.getLong("testModeOnTs", 0L)
        set(v) = p.edit().putLong("testModeOnTs", v).apply()

    // ---------- HTML overlay content ----------
    var htmlContent: String
        get() = p.getString("htmlContent", "") ?: ""
        set(v) = p.edit().putString("htmlContent", v).apply()

    // ---------- Recovery / lockout ----------
    var failedAttempts: Int
        get() = p.getInt("failedAttempts", 0)
        set(v) = p.edit().putInt("failedAttempts", v).apply()

    var lockoutUntil: Long
        get() = p.getLong("lockoutUntil", 0L)
        set(v) = p.edit().putLong("lockoutUntil", v).apply()

    fun lockedOut(): Boolean = System.currentTimeMillis() < lockoutUntil

    // Set true the moment the recovery phrase is accepted; stays true (and
    // bypasses both the overlay gate and the Setup gate) until a new code is
    // confirmed. The OLD code is deliberately left untouched until then, so
    // a power loss mid-flow just leaves the old code working.
    var recoveryModeActive: Boolean
        get() = p.getBoolean("recoveryModeActive", false)
        set(v) = p.edit().putBoolean("recoveryModeActive", v).apply()
}
