# Device Care (deadman check-in, remote trigger) — v4

Disguised as a storage/cleanup utility. Android 8+ (built for Android 10,
targetSdk 29). No Device Owner — no "monitored" notice.

## What's in v4
- **Gatekeep** (full lock, Back disabled) and **Repeater** (pops up every
  30s, Back dismisses it) are now independent modes — local toggles in the
  app, PLUS independent remote triggers from the webpage. Either source can
  fire either mode.
- **Dead-man timer** is its own toggle with a minutes field, synced two-way
  with the webpage by "most recent change wins" (timestamped).
- **Pause**: webpage sets a countdown that overrides every other trigger.
  Cached locally so it keeps counting down even if the tablet goes offline;
  if the countdown expires while offline, it falls back to whatever local
  Gatekeep/Repeater toggles are on (never silently stays unlockable forever).
- **Disable**: remote "wipe this installation" command. Tablet confirms once
  applied; you clear that confirmation yourself before reusing the slot. Can
  be cancelled from the webpage before the tablet checks in.
- **Reset Timer**: one button, works from the tablet or the webpage.
- **Change code**: push a new code from the webpage; confirmed status shown
  once the tablet applies it.
- **Custom lock-screen content**: optional HTML (e.g. "lost tablet, call
  555-1234") shown instead of the plain black screen, with a Preview button
  in Setup.
- **Hidden gesture** to reveal the unlock panel: long-hold, tap-then-hold, or
  double-tap-then-hold, your choice. **Test Mode** adds two independent
  3-minute safety nets (auto-reveal if the gesture never registers; auto
  stand-down if the unlock panel sits untouched) so testing can never
  reproduce the v1 lock-out.
- **Recovery phrase**: hardcoded, offline, bypasses everything, forces a
  brand-new code before you can do anything else. The OLD code is left alone
  until the new one is confirmed, so a dead battery mid-flow can't strand you
  on no code at all.
- **Escalating lockout** on wrong code/recovery attempts: 5→30s, 10→1min,
  15→5min, 20+→caps at 15min.
- Tablet ID is now a dropdown (tablet1–tablet20) with a warning if that slot
  checked in recently under another device.

## Build on GitHub
1. Private repo, upload `deadman-remote.zip` to the repo root, and
   `.github/workflows/build.yml` to that exact path.
2. Actions tab -> Build APK -> download `deadman-remote-apk`.
3. Same APK for all tablets — set a different Tablet ID per device in Setup.

## Install (per tablet)
1. `adb install app-debug.apk`
2. Open "Device Care". Tap the four Permissions buttons in order: device
   admin, overlay, accessibility, battery.
3. Setup: Tablet ID, time limit, code + confirm. Save & start.
4. Grant the one permission the app can't ask for itself:
   ```
   pm grant com.util.devicecare android.permission.WRITE_SECURE_SETTINGS
   ```
5. **Tap "Test lock now" with Test Mode on, and confirm your gesture works
   and you can get back in before trusting this on a real device.**

## Recovery phrase
Hardcoded in `Config.kt` (`RECOVERY_PHRASE`, `RECOVERY_HINT`). Works with
zero connectivity. Entering it on the lock screen (same field as the normal
code) immediately forces a new-code screen — there's no way around setting
a new code once it's accepted.

## Uninstall
App > Remove (enter code) deactivates device admin. Then Settings >
Accessibility > turn the service off. Then uninstall normally.
