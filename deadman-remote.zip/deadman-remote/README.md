# Device Care (deadman check-in, remote trigger) — v3

Disguised as a storage/cleanup utility — the kind of app a thief clearing
space might delete rather than one they'd open. v2 fixed a critical bug
from v1: the lock
service called lockNow() every time the screen turned on, which creates an
infinite screen on/off loop with no way to enter the code — this bricked a
tablet. v2 now locks ONCE per trigger (guarded by Store.initialLockDone) and
uses only the overlay on subsequent screen-on events.

Android 8+ (built for Android 10). No Device Owner — no "monitored" notice.

## Build on GitHub
1. Private repo, upload `deadman-remote.zip` to the repo root, and
   `.github/workflows/build.yml` to that exact path.
2. Actions tab -> Build APK -> download `deadman-remote-apk`.
3. Same APK for all tablets — set a different Tablet ID per device in Setup.

## Install (per tablet)
1. `adb install app-debug.apk`
2. Open "Device Care". Tap the four Permissions buttons in order: device
   admin, overlay, accessibility, battery.
3. Setup: Tablet ID (must match the web switch panel), time limit, code.
   Save & start.
4. Grant the one permission the app can't ask for itself:
   ```
   pm grant com.util.devicecare android.permission.WRITE_SECURE_SETTINGS
   ```
5. **Tap "Test lock now" and confirm you can enter your code and get back
   in before trusting this on a real device.** This is the step that
   would have caught the v1 bug.

## How it decides to lock
Every ~15 min: checks the Firebase `triggered` flag for this Tablet ID,
then the check-in timer. On a fresh trigger, it locks the screen once and
shows the overlay. On every later screen-on while still triggered, it only
re-shows the overlay — it does not call lockNow() again.

## Unlocking
Code on the overlay (or Check-in in the app) clears the local triggered
state and gives a 10-minute snooze window so you can deactivate admin and
uninstall if needed. It does not clear the Firebase flag — flip that off
in the web panel too, or it will re-lock once the snooze ends and it's
back online.

## Uninstall
App > Remove (enter code) deactivates device admin. Then Settings >
Accessibility > turn the service off. Then uninstall normally.
