# File Manager (deadman check-in, remote trigger)

Disguised as a generic "File Manager" app. Locks the tablet with its own
overlay screen if you don't check in within a time limit, OR the moment you
flip its switch on your web panel. No Device Owner, so no "this device is
monitored" notice.

Android 8+ (built for Android 10). Needs: device admin, "display over other
apps" permission, and an accessibility service — all granted from inside the
app or via adb, see below.

## Build on GitHub
1. Create a **private** repo, upload all these files, push to `main`.
2. Actions tab -> "Build APK" -> download the `deadman-checkin-apk` artifact
   (app-debug.apk). Repeat for each tablet (same APK works for all of them —
   you set the Tablet ID per device inside the app).

## Install (per tablet)
1. `adb install app-debug.apk`
2. Open the app ("File Manager"). Tap through the four buttons under
   **Permissions** in order: device admin, overlay, accessibility, battery.
3. Under **Setup**, enter a Tablet ID (must match a name in the web switch
   panel, e.g. `tablet1`), a time limit, and your code (used for check-in,
   test, and remove). Tap **Save & start**.
4. In WebADB (or adb shell), grant the one permission the app can't ask for
   itself, so it can keep re-enabling its own accessibility service if
   something tries to turn it off:
   ```
   pm grant com.util.filemanager android.permission.WRITE_SECURE_SETTINGS
   ```
5. Tap **Test lock now** to confirm the overlay shows up and your code clears
   it. Test with a short time limit first before trusting the full timer.

## How it decides to lock
Every ~15 minutes it checks, in order:
- Is the tablet's `triggered` flag `true` in Firebase (you flipped the
  switch)?
- Has the check-in timer run out?

If either is true, it sets `triggered` locally and starts the lock service,
which re-locks and re-shows the overlay every time the screen turns on, and
kicks you out of Settings/notification shade while it's active.

## Unlocking
Enter your code on the overlay (or in the app's Check-in box). This clears
the **local** triggered state and gives you a 10-minute window where it won't
re-trigger — enough time to deactivate the admin and uninstall if needed. It
does **not** clear the Firebase flag. If you don't flip the switch off in the
web panel within those 10 minutes (or before reconnecting to Wi-Fi), it will
lock itself again on the next check — intentional, as a backstop in case
someone guessed the code.

## Uninstall
In the app, enter your code under **Remove**, tap it (this deactivates device
admin for you), then go to Settings > Accessibility and turn the service off,
then uninstall normally.
